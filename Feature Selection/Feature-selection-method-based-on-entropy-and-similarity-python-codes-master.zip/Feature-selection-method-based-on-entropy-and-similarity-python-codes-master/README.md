# Feature-selection-method-based-on-entropy-and-similarity-python-codes

Feature selection method using similarity measure and fuzzy entroropy 
 measures based on the article:

 P. Luukka, (2011) Feature Selection Using Fuzzy Entropy Measures with
 Similarity Classifier, Expert Systems with Applications, 38, pp.
 4600-4607
Two files included from this:

1.	FSsimilarityPL.ipynb: Python notebook file including the feature selection function
2.	Feature_selection_PL: Python notebook file including the function and examples of the use of the function

Special thanks from this goes to Mahinda Mailagaha Kumbure

For matlab codes see:

https://se.mathworks.com/matlabcentral/fileexchange/31366-feature-selection-using-fuzzy-entropy-measures-and-similarity

